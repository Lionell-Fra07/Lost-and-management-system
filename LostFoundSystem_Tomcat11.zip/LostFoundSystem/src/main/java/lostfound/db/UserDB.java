package lostfound.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import lostfound.beans.ConnectionBean;
import lostfound.beans.UserBean;
import lostfound.util.SqlHelper;

/**
 * All SQL for the Users table. Follows Notes 5.1: get a Connection, createStatement(),
 * executeUpdate() for INSERT/UPDATE, executeQuery() for SELECT, read the ResultSet with rs.next(),
 * and close everything with try-with-resources.
 * Has a public no-argument constructor, so a page can create it with <jsp:useBean>.
 */
public class UserDB {

    private final ConnectionBean connectionBean = new ConnectionBean();

    private static final String COLUMNS = "user_id, full_name, email, password, contact_number";

    /** Saves a new user. The password in the bean must already be hashed. */
    public void register(UserBean user) {
        String sql = "INSERT INTO Users (full_name, email, password, contact_number) VALUES ("
                + SqlHelper.quote(user.getFullName()) + ", "
                + SqlHelper.quote(user.getEmail()) + ", "
                + SqlHelper.quote(user.getPassword()) + ", "
                + SqlHelper.quote(user.getContactNumber()) + ")";
        try (Connection con = connectionBean.getConnection(); Statement st = con.createStatement()) {
            st.executeUpdate(sql);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    /** True if a different user (any id except excludeUserId) already uses this email. */
    public boolean emailExists(String email, int excludeUserId) {
        String sql = "SELECT COUNT(*) FROM Users WHERE email = " + SqlHelper.quote(email)
                + " AND user_id <> " + excludeUserId;
        try (Connection con = connectionBean.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public UserBean findByEmail(String email) {
        return findOne("SELECT " + COLUMNS + " FROM Users WHERE email = " + SqlHelper.quote(email));
    }

    public UserBean findById(int userId) {
        return findOne("SELECT " + COLUMNS + " FROM Users WHERE user_id = " + userId);
    }

    /** Updates name, email and contact number; the password only when newPasswordHash is not null. */
    public void updateProfile(UserBean user, String newPasswordHash) {
        String sql = "UPDATE Users SET full_name = " + SqlHelper.quote(user.getFullName())
                + ", email = " + SqlHelper.quote(user.getEmail())
                + ", contact_number = " + SqlHelper.quote(user.getContactNumber());
        if (newPasswordHash != null) {
            sql += ", password = " + SqlHelper.quote(newPasswordHash);
        }
        sql += " WHERE user_id = " + user.getUserId();
        try (Connection con = connectionBean.getConnection(); Statement st = con.createStatement()) {
            st.executeUpdate(sql);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    private UserBean findOne(String sql) {
        try (Connection con = connectionBean.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                UserBean u = new UserBean();
                u.setUserId(rs.getInt("user_id"));
                u.setFullName(rs.getString("full_name"));
                u.setEmail(rs.getString("email"));
                u.setPassword(rs.getString("password"));
                u.setContactNumber(rs.getString("contact_number"));
                return u;
            }
            return null;
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }
}
