package lostfound.db;

import java.sql.SQLException;

/**
 * Wraps a SQLException so JSP pages (which cannot easily catch checked exceptions) can simply let
 * it travel to the error page (Notes 7.1: errorPage / isErrorPage).
 * Keeps the MySQL error code (Notes 5.1, section 7: getErrorCode) so a duplicate email (1062) can be recognised.
 */
public class DatabaseException extends RuntimeException {

    public static final int DUPLICATE_ENTRY = 1062;

    private final int sqlErrorCode;

    public DatabaseException(SQLException cause) {
        super("Database error: " + cause.getMessage(), cause);
        this.sqlErrorCode = cause.getErrorCode();
    }

    public int getSqlErrorCode() {
        return sqlErrorCode;
    }

    public boolean isDuplicateEntry() {
        return sqlErrorCode == DUPLICATE_ENTRY;
    }
}
