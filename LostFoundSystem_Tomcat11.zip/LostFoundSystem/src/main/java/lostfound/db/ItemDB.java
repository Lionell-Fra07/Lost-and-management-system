package lostfound.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lostfound.beans.ConnectionBean;
import lostfound.beans.ItemBean;
import lostfound.util.SqlHelper;

/**
 * All SQL for the LostFoundItems table (Notes 5.1 pattern, see UserDB).
 * Every page asks the database every time it is shown, so changes appear immediately.
 */
public class ItemDB {

    private final ConnectionBean connectionBean = new ConnectionBean();

    private static final String SELECT =
            "SELECT item_id, user_id, item_name, item_type, description, location, "
            + "date_reported, report_type, status FROM LostFoundItems";
    private static final String NEWEST_FIRST = " ORDER BY date_reported DESC, item_id DESC";

    // ---------------------------------------------------------------- create / update / delete

    /** Inserts a new item and returns its new item_id. */
    public int add(ItemBean item) {
        String sql = "INSERT INTO LostFoundItems "
                + "(user_id, item_name, item_type, description, location, date_reported, report_type, status) VALUES ("
                + item.getUserId() + ", "
                + SqlHelper.quote(item.getItemName()) + ", "
                + SqlHelper.quote(item.getItemType()) + ", "
                + SqlHelper.quote(item.getDescription()) + ", "
                + SqlHelper.quote(item.getLocation()) + ", "
                + SqlHelper.quote(item.getDateReportedIso()) + ", "
                + SqlHelper.quote(item.getReportType()) + ", "
                + SqlHelper.quote(item.getStatus()) + ")";
        try (Connection con = connectionBean.getConnection(); Statement st = con.createStatement()) {
            st.executeUpdate(sql);
            try (ResultSet rs = st.executeQuery("SELECT LAST_INSERT_ID()")) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public void update(ItemBean item) {
        String sql = "UPDATE LostFoundItems SET "
                + "item_name = " + SqlHelper.quote(item.getItemName())
                + ", item_type = " + SqlHelper.quote(item.getItemType())
                + ", description = " + SqlHelper.quote(item.getDescription())
                + ", location = " + SqlHelper.quote(item.getLocation())
                + ", date_reported = " + SqlHelper.quote(item.getDateReportedIso())
                + ", report_type = " + SqlHelper.quote(item.getReportType())
                + ", status = " + SqlHelper.quote(item.getStatus())
                + " WHERE item_id = " + item.getItemId();
        execute(sql);
    }

    public void markClaimed(int itemId) {
        execute("UPDATE LostFoundItems SET status = 'Claimed' WHERE item_id = " + itemId);
    }

    public void delete(int itemId) {
        execute("DELETE FROM LostFoundItems WHERE item_id = " + itemId);
    }

    // ---------------------------------------------------------------- read

    public List<ItemBean> findAll() {
        return query(SELECT + NEWEST_FIRST);
    }

    public List<ItemBean> findRecent(int howMany) {
        return query(SELECT + NEWEST_FIRST + " LIMIT " + Math.max(1, howMany));
    }

    public ItemBean findById(int itemId) {
        List<ItemBean> found = query(SELECT + " WHERE item_id = " + itemId);
        return found.isEmpty() ? null : found.get(0);
    }

    /**
     * Search with LIKE (as in the Notes 8.1 examples).
     * searchBy = "name" (Item Name), "location" (Location) or anything else for both.
     */
    public List<ItemBean> search(String text, String searchBy) {
        String pattern = SqlHelper.likeContains(text);
        String where;
        if ("name".equals(searchBy)) {
            where = " WHERE item_name LIKE " + pattern;
        } else if ("location".equals(searchBy)) {
            where = " WHERE location LIKE " + pattern;
        } else {
            where = " WHERE (item_name LIKE " + pattern + " OR location LIKE " + pattern + ")";
        }
        return query(SELECT + where + NEWEST_FIRST);
    }

    // ---------------------------------------------------------------- dashboard counts

    public int countAll() {
        return count("SELECT COUNT(*) FROM LostFoundItems");
    }

    public int countByStatus(String status) {
        return count("SELECT COUNT(*) FROM LostFoundItems WHERE status = " + SqlHelper.quote(status));
    }

    // ---------------------------------------------------------------- helpers

    private void execute(String sql) {
        try (Connection con = connectionBean.getConnection(); Statement st = con.createStatement()) {
            st.executeUpdate(sql);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    /** The "if(rs.next()) rs.getInt(1)" pattern from Notes 5.1 for COUNT(*) queries. */
    private int count(String sql) {
        try (Connection con = connectionBean.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    /** The "while(rs.next())" loop from Notes 5.1, section 5.1. */
    private List<ItemBean> query(String sql) {
        List<ItemBean> items = new ArrayList<ItemBean>();
        try (Connection con = connectionBean.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                ItemBean item = new ItemBean();
                item.setItemId(rs.getInt("item_id"));
                item.setUserId(rs.getInt("user_id"));
                item.setItemName(rs.getString("item_name"));
                item.setItemType(rs.getString("item_type"));
                item.setDescription(rs.getString("description"));
                item.setLocation(rs.getString("location"));
                // a DATE column read as text looks like 2026-09-10
                item.setDateReported(LocalDate.parse(rs.getString("date_reported")));
                item.setReportType(rs.getString("report_type"));
                item.setStatus(rs.getString("status"));
                items.add(item);
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
        return items;
    }
}
