package lostfound.beans;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * JavaBean for one lost or found item.
 * The claim deadline is never stored in the database: it is worked out here as
 * Date Reported + 14 days, and only for items whose Report Type is Found.
 *
 * Property sheet:
 *   Name               Access      Java type   Example value
 *   itemId             read/write  int         7
 *   userId             read/write  int         1
 *   itemName           read/write  String      Black wallet
 *   itemType           read/write  String      Personal Item
 *   description        read/write  String      Leather, Nike logo
 *   location           read/write  String      Library, 2nd floor
 *   dateReported       read/write  LocalDate   2026-09-10
 *   reportType         read/write  String      Found
 *   status             read/write  String      Unclaimed
 *   found              read-only   boolean     true
 *   claimed            read-only   boolean     false
 *   claimDeadline      read-only   LocalDate   2026-09-24   (null for Lost items)
 *   claimDeadlineText  read-only   String      24 September 2026
 *   dateReportedText   read-only   String      10 September 2026
 *   dateReportedIso    read-only   String      2026-09-10
 *   deadlinePassed     read-only   boolean     false
 */
public class ItemBean implements Serializable {

    public static final String LOST = "Lost";
    public static final String FOUND = "Found";
    public static final String UNCLAIMED = "Unclaimed";
    public static final String CLAIMED = "Claimed";
    public static final int CLAIM_DAYS = 14;

    public static final List<String> TYPES = Collections.unmodifiableList(
            Arrays.asList("Electronic", "Personal Item", "Clothing", "Other"));
    public static final List<String> REPORT_TYPES = Collections.unmodifiableList(
            Arrays.asList(LOST, FOUND));
    public static final List<String> STATUSES = Collections.unmodifiableList(
            Arrays.asList(UNCLAIMED, CLAIMED));

    private static final DateTimeFormatter DISPLAY =
            DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH);

    private int itemId;
    private int userId;
    private String itemName = "";
    private String itemType = "";
    private String description = "";
    private String location = "";
    private LocalDate dateReported;
    private String reportType = LOST;
    private String status = UNCLAIMED;

    public ItemBean() {
    }

    public int getItemId() { return itemId; }
    public void setItemId(int itemId) { this.itemId = itemId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public String getItemType() { return itemType; }
    public void setItemType(String itemType) { this.itemType = itemType; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public LocalDate getDateReported() { return dateReported; }
    public void setDateReported(LocalDate dateReported) { this.dateReported = dateReported; }

    public String getReportType() { return reportType; }
    public void setReportType(String reportType) { this.reportType = reportType; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // ---- read-only properties (calculated) ----

    /** True when the Report Type is Found. */
    public boolean isFound() {
        return FOUND.equals(reportType);
    }

    public boolean isClaimed() {
        return CLAIMED.equals(status);
    }

    /** Date Reported + 14 days for Found items; null for Lost items. */
    public LocalDate getClaimDeadline() {
        if (isFound() && dateReported != null) {
            return dateReported.plusDays(CLAIM_DAYS);
        }
        return null;
    }

    public String getClaimDeadlineText() {
        LocalDate deadline = getClaimDeadline();
        return deadline == null ? "" : deadline.format(DISPLAY);
    }

    public String getDateReportedText() {
        return dateReported == null ? "" : dateReported.format(DISPLAY);
    }

    /** yyyy-MM-dd, the format an HTML date box and MySQL both use. */
    public String getDateReportedIso() {
        return dateReported == null ? "" : dateReported.toString();
    }

    /** True when a found item is still unclaimed after its claim deadline. */
    public boolean isDeadlinePassed() {
        LocalDate deadline = getClaimDeadline();
        return deadline != null && !isClaimed() && deadline.isBefore(LocalDate.now());
    }
}
