package lostfound.beans;

import java.io.Serializable;

/**
 * JavaBean for one registered user (Notes 8.1: Serializable, no-argument constructor, get/set accessors).
 *
 * Property sheet:
 *   Name           Access      Java type   Example value
 *   userId         read/write  int         1
 *   fullName       read/write  String      Lionell Franse
 *   email          read/write  String      lionell@example.com
 *   password       read/write  String      (the stored salt:hash, never the typed password)
 *   contactNumber  read/write  String      082 123 4567
 */
public class UserBean implements Serializable {

    private int userId;
    private String fullName = "";
    private String email = "";
    private String password = "";
    private String contactNumber = "";

    public UserBean() {
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
}
