package lostfound.beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Connection bean (Notes 8.1, section 2.13). Every database class asks this bean for a connection,
 * so the database address, user name and password are written in ONE place only.
 * Uses DriverManager.getConnection(url, user, password) from Notes 5.1.
 * The MySQL connector JAR must be added to the project's Libraries (Notes 5.1, section 2.3).
 *
 * Property sheet:
 *   Name        Access      Java type    Example value
 *   connection  read-only   Connection   instance of Connection
 */
public class ConnectionBean implements Serializable {

    // ----- CHANGE THESE THREE TO MATCH YOUR MYSQL INSTALLATION -----
    private static final String URL =
            "jdbc:mysql://localhost:3306/lostfound_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Africa/Johannesburg";
    private static final String USER = "root";
    private static final String PASSWORD = "your_mysql_password";
    // ---------------------------------------------------------------

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError(
                    "MySQL driver not found. Add the mysql-connector-java JAR to the project Libraries.");
        }
    }

    public ConnectionBean() {
    }

    /** A new connection. Callers close it with try-with-resources (Notes 5.1, section 6). */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
