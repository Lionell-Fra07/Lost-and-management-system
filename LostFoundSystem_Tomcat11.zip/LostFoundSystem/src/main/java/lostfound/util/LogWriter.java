package lostfound.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Java file logging.
 * Every time an item is added, updated, marked as claimed or deleted, one line is appended to the log file:
 *
 *     date and time | user email | action performed | item name
 *
 * Uses File, FileWriter(String, boolean append) and PrintWriter from Notes 2.1 (character streams / file I/O).
 * Location: the "logs" folder of Tomcat (catalina.base). If that is not available, your user home folder.
 */
public class LogWriter {

    public static final String ADDED = "ADDED";
    public static final String UPDATED = "UPDATED";
    public static final String CLAIMED = "MARKED AS CLAIMED";
    public static final String DELETED = "DELETED";

    private static final String FILE_NAME = "lostfound.log";
    private static final Logger LOG = Logger.getLogger("LogWriter");

    private LogWriter() {
    }

    /** The log file (the folder is created if it does not exist yet). */
    public static File getLogFile() {
        File folder = new File(System.getProperty("catalina.base", System.getProperty("user.home")), "logs");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return new File(folder, FILE_NAME);
    }

    /** synchronized so two users acting at the same moment cannot mix up their lines. */
    public static synchronized void log(String userEmail, String action, String itemName) {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        File logFile = getLogFile();
        // true = append, so earlier lines are kept
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(logFile, true)))) {
            out.println(time + " | " + oneLine(userEmail) + " | " + action + " | " + oneLine(itemName));
        } catch (IOException e) {
            LOG.log(Level.WARNING, "Could not write to log file {0}", logFile.getAbsolutePath());
        }
    }

    /** Removes line breaks so one action is always exactly one line. */
    private static String oneLine(String text) {
        return text == null ? "" : text.replace("\r", " ").replace("\n", " ");
    }
}
