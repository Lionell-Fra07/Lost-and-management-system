package lostfound.util;

/**
 * The notes run SQL with a Statement (Notes 5.1), so text typed by users has to be made safe
 * before it is placed inside a SQL string. quote() wraps the text in single quotes and escapes
 * any quote or backslash, so a user cannot break out of the string (SQL injection).
 */
public class SqlHelper {

    private SqlHelper() {
    }

    /** Turns text into a safe SQL string literal, e.g. O'Brien becomes 'O''Brien'. */
    public static String quote(String text) {
        if (text == null) {
            return "NULL";
        }
        return "'" + text.replace("\\", "\\\\").replace("'", "''") + "'";
    }

    /** Builds a safe LIKE pattern, e.g. wallet becomes '%wallet%' (the % and _ typed by a user are not wildcards). */
    public static String likeContains(String text) {
        String t = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
        return quote("%" + t + "%");
    }
}
