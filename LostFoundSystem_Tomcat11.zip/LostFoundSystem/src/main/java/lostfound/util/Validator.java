package lostfound.util;

/** Input validation and HTML escaping used by the servlets and JSP pages. */
public class Validator {

    public static final String PASSWORD_RULE =
            "Password must be at least 8 characters and contain at least one letter and one number.";

    private Validator() {
    }

    /** Trims the text; null becomes an empty string. */
    public static String clean(String text) {
        return text == null ? "" : text.trim();
    }

    public static boolean isBlank(String text) {
        return text == null || text.trim().isEmpty();
    }

    /** Simple email check: text@text.text with no spaces. */
    public static boolean isValidEmail(String email) {
        if (email == null || email.length() > 150 || email.indexOf(' ') >= 0) {
            return false;
        }
        int at = email.indexOf('@');
        if (at < 1 || at != email.lastIndexOf('@')) {
            return false;
        }
        int dot = email.lastIndexOf('.');
        return dot > at + 1 && dot < email.length() - 1;
    }

    /** Contact number: 7 to 20 characters, digits plus the characters + ( ) - and spaces. */
    public static boolean isValidPhone(String phone) {
        if (phone == null || phone.length() < 7 || phone.length() > 20) {
            return false;
        }
        int digits = 0;
        for (int i = 0; i < phone.length(); i++) {
            char c = phone.charAt(i);
            if (Character.isDigit(c)) {
                digits++;
            } else if ("+()- ".indexOf(c) < 0) {
                return false;
            }
        }
        return digits >= 7;
    }

    /** At least 8 characters with at least one letter and one digit. */
    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8 || password.length() > 100) {
            return false;
        }
        boolean letter = false;
        boolean digit = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isLetter(c)) {
                letter = true;
            } else if (Character.isDigit(c)) {
                digit = true;
            }
        }
        return letter && digit;
    }

    /**
     * Escapes text before it is printed on a page, using the HTML entities from Notes 6.1
     * (&amp; &lt; &gt;). This stops a user from sneaking HTML or script into a page.
     */
    public static String html(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                   .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
