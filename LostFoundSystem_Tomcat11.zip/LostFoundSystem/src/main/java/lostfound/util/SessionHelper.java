package lostfound.util;

import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.UserBean;

/**
 * Helps servlets and JSP pages share information through the session (Notes 7.1: session object,
 * setAttribute / getAttribute).
 *
 *   "user"     the logged-in UserBean
 *   "message"  a success message to show once on the next page
 *   "errors"   a list of error messages to show once on the next page
 *   "formUser" / "formItem"  what the user typed, so a form can be filled in again after an error
 */
public class SessionHelper {

    private SessionHelper() {
    }

    public static UserBean getUser(HttpSession session) {
        return session == null ? null : (UserBean) session.getAttribute("user");
    }

    public static void message(HttpSession session, String text) {
        session.setAttribute("message", text);
    }

    public static void error(HttpSession session, String text) {
        List<String> errors = new ArrayList<String>();
        errors.add(text);
        session.setAttribute("errors", errors);
    }

    public static void errors(HttpSession session, List<String> errors) {
        session.setAttribute("errors", errors);
    }
}
