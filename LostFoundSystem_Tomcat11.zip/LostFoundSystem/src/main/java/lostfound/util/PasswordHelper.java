package lostfound.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Stores passwords securely (the brief says "Store passwords securely").
 * The password is never saved as typed. A random salt is added and the result is hashed with SHA-256.
 * Stored format:  salt:hash   (both in hexadecimal).
 *
 * NOTE: hashing is not taught in the course notes. This one small class uses only the standard
 * JDK (java.security) to meet that line of the brief.
 */
public class PasswordHelper {

    private static final int ROUNDS = 10000; // repeat the hash to make guessing slower

    private PasswordHelper() {
    }

    public static String hash(String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String saltHex = toHex(salt);
        return saltHex + ":" + digest(saltHex, password);
    }

    public static boolean verify(String password, String stored) {
        if (password == null || stored == null) {
            return false;
        }
        int colon = stored.indexOf(':');
        if (colon < 1) {
            return false;
        }
        String saltHex = stored.substring(0, colon);
        String expected = stored.substring(colon + 1);
        return MessageDigest.isEqual(expected.getBytes(), digest(saltHex, password).getBytes());
    }

    private static String digest(String saltHex, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] result = md.digest((saltHex + password).getBytes("UTF-8"));
            for (int i = 1; i < ROUNDS; i++) {
                result = md.digest(result);
            }
            return toHex(result);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        } catch (java.io.UnsupportedEncodingException e) {
            throw new IllegalStateException("UTF-8 is not available", e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
