package lostfound.servlets;

import java.io.IOException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.ItemBean;
import lostfound.beans.UserBean;
import lostfound.db.DatabaseException;
import lostfound.db.ItemDB;
import lostfound.util.LogWriter;
import lostfound.util.SessionHelper;

/** MARK ITEM AS CLAIMED. Changes the status from Unclaimed to Claimed. */
public class ClaimItemServlet extends HttpServlet {

    private final ItemDB itemDB = new ItemDB();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/items.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        UserBean user = SessionHelper.getUser(session);
        if (user == null) {
            SessionHelper.error(session, "Please log in to continue.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int id = parseId(request.getParameter("id"));
        String back = request.getContextPath() + "/items.jsp";
        try {
            ItemBean item = itemDB.findById(id);
            if (item == null) {
                SessionHelper.error(session, "That item could not be found. It may have been deleted.");
            } else if (item.isClaimed()) {
                SessionHelper.error(session, "\"" + item.getItemName() + "\" has already been marked as claimed.");
            } else {
                itemDB.markClaimed(id);
                LogWriter.log(user.getEmail(), LogWriter.CLAIMED, item.getItemName());
                SessionHelper.message(session, "\"" + item.getItemName() + "\" has been marked as claimed.");
                if ("view".equals(request.getParameter("from"))) {
                    back = request.getContextPath() + "/item-view.jsp?id=" + id;
                }
            }
        } catch (DatabaseException e) {
            System.err.println("Claim item failed: " + e.getMessage());
            SessionHelper.error(session, "A database error occurred. Please try again later.");
        }
        response.sendRedirect(back);
    }

    private int parseId(String text) {
        try {
            return Integer.parseInt(text == null ? "" : text.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
