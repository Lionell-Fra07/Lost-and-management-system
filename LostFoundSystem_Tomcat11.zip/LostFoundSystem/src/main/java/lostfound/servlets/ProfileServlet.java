package lostfound.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.UserBean;
import lostfound.db.DatabaseException;
import lostfound.db.UserDB;
import lostfound.util.PasswordHelper;
import lostfound.util.SessionHelper;
import lostfound.util.Validator;

/** PROFILE MANAGEMENT. Updates full name, email, contact number and (optionally) the password. */
public class ProfileServlet extends HttpServlet {

    private final UserDB userDB = new UserDB();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/profile.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        UserBean current = SessionHelper.getUser(session);
        if (current == null) {
            SessionHelper.error(session, "Please log in to continue.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String fullName = Validator.clean(request.getParameter("fullName"));
        String email = Validator.clean(request.getParameter("email")).toLowerCase();
        String contact = Validator.clean(request.getParameter("contactNumber"));
        String currentPassword = request.getParameter("currentPassword") == null ? "" : request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword") == null ? "" : request.getParameter("newPassword");
        String confirm = request.getParameter("confirmPassword") == null ? "" : request.getParameter("confirmPassword");

        List<String> errors = new ArrayList<String>();
        if (fullName.isEmpty()) {
            errors.add("Full name is required.");
        } else if (fullName.length() > 100) {
            errors.add("Full name must be 100 characters or fewer.");
        }
        if (email.isEmpty()) {
            errors.add("Email address is required.");
        } else if (!Validator.isValidEmail(email)) {
            errors.add("Please enter a valid email address.");
        }
        if (contact.isEmpty()) {
            errors.add("Contact number is required.");
        } else if (!Validator.isValidPhone(contact)) {
            errors.add("Please enter a valid contact number (digits, spaces and + ( ) - only).");
        }

        boolean changePassword = !newPassword.isEmpty();
        try {
            if (changePassword) {
                UserBean stored = userDB.findById(current.getUserId());
                if (stored == null || !PasswordHelper.verify(currentPassword, stored.getPassword())) {
                    errors.add("Your current password is incorrect.");
                }
                if (!Validator.isValidPassword(newPassword)) {
                    errors.add(Validator.PASSWORD_RULE);
                } else if (!newPassword.equals(confirm)) {
                    errors.add("The new passwords do not match.");
                }
            }
            if (errors.isEmpty() && userDB.emailExists(email, current.getUserId())) {
                errors.add("That email address is already used by another account.");
            }
            if (errors.isEmpty()) {
                UserBean updated = new UserBean();
                updated.setUserId(current.getUserId());
                updated.setFullName(fullName);
                updated.setEmail(email);
                updated.setContactNumber(contact);
                userDB.updateProfile(updated, changePassword ? PasswordHelper.hash(newPassword) : null);

                // keep the session in step with the database
                current.setFullName(fullName);
                current.setEmail(email);
                current.setContactNumber(contact);
                SessionHelper.message(session, "Your profile has been updated.");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
                return;
            }
        } catch (DatabaseException e) {
            if (e.isDuplicateEntry()) {
                errors.add("That email address is already used by another account.");
            } else {
                System.err.println("Profile update failed: " + e.getMessage());
                errors.add("A database error occurred. Please try again later.");
            }
        }

        UserBean typed = new UserBean();
        typed.setFullName(fullName);
        typed.setEmail(email);
        typed.setContactNumber(contact);
        session.setAttribute("formUser", typed);
        SessionHelper.errors(session, errors);
        response.sendRedirect(request.getContextPath() + "/profile.jsp");
    }
}
