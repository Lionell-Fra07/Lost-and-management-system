package lostfound.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.ItemBean;
import lostfound.beans.UserBean;
import lostfound.db.DatabaseException;
import lostfound.db.ItemDB;
import lostfound.util.LogWriter;
import lostfound.util.SessionHelper;

/** REPORT AN ITEM. New items are always saved with the status Unclaimed. */
public class AddItemServlet extends HttpServlet {

    private final ItemDB itemDB = new ItemDB();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/item-form.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        UserBean user = SessionHelper.getUser(session);
        if (user == null) {                       // protected function: logged-in users only
            SessionHelper.error(session, "Please log in to continue.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        List<String> errors = new ArrayList<String>();
        ItemBean item = ItemForm.read(request, errors, false);
        if (errors.isEmpty()) {
            try {
                item.setUserId(user.getUserId());
                item.setStatus(ItemBean.UNCLAIMED);
                int newId = itemDB.add(item);
                LogWriter.log(user.getEmail(), LogWriter.ADDED, item.getItemName());

                String text = "Item reported successfully.";
                if (item.isFound()) {
                    text += " Claim deadline: " + item.getClaimDeadlineText() + ".";
                }
                SessionHelper.message(session, text);
                response.sendRedirect(request.getContextPath() + "/item-view.jsp?id=" + newId);
                return;
            } catch (DatabaseException e) {
                System.err.println("Add item failed: " + e.getMessage());
                errors.add("A database error occurred. Please try again later.");
            }
        }
        session.setAttribute("formItem", item);   // keep what was typed
        SessionHelper.errors(session, errors);
        response.sendRedirect(request.getContextPath() + "/item-form.jsp");
    }
}
