package lostfound.servlets;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import jakarta.servlet.http.HttpServletRequest;
import lostfound.beans.ItemBean;
import lostfound.util.Validator;

/** Reads and validates the report/update item form (used by AddItemServlet and UpdateItemServlet). */
class ItemForm {

    private ItemForm() {
    }

    /** Problems found are added to errors. The returned bean holds whatever was typed. */
    static ItemBean read(HttpServletRequest request, List<String> errors, boolean includeStatus) {
        ItemBean item = new ItemBean();
        item.setItemName(Validator.clean(request.getParameter("itemName")));
        item.setItemType(Validator.clean(request.getParameter("itemType")));
        item.setDescription(Validator.clean(request.getParameter("description")));
        item.setLocation(Validator.clean(request.getParameter("location")));
        item.setReportType(Validator.clean(request.getParameter("reportType")));
        // A new item is ALWAYS Unclaimed; the status can only be chosen when editing
        item.setStatus(includeStatus ? Validator.clean(request.getParameter("status")) : ItemBean.UNCLAIMED);

        if (item.getItemName().isEmpty()) {
            errors.add("Item name is required.");
        } else if (item.getItemName().length() > 100) {
            errors.add("Item name must be 100 characters or fewer.");
        }
        if (!ItemBean.TYPES.contains(item.getItemType())) {
            errors.add("Please choose an item type.");
        }
        if (item.getDescription().isEmpty()) {
            errors.add("Description is required.");
        } else if (item.getDescription().length() > 500) {
            errors.add("Description must be 500 characters or fewer.");
        }
        if (item.getLocation().isEmpty()) {
            errors.add("Location is required.");
        } else if (item.getLocation().length() > 150) {
            errors.add("Location must be 150 characters or fewer.");
        }
        if (!ItemBean.REPORT_TYPES.contains(item.getReportType())) {
            errors.add("Please choose a report type (Lost or Found).");
        }
        if (includeStatus && !ItemBean.STATUSES.contains(item.getStatus())) {
            errors.add("Please choose a valid status.");
        }

        String date = Validator.clean(request.getParameter("dateReported"));
        if (date.isEmpty()) {
            errors.add("Date reported is required.");
        } else {
            try {
                LocalDate parsed = LocalDate.parse(date);
                if (parsed.isAfter(LocalDate.now())) {
                    errors.add("Date reported cannot be in the future.");
                } else {
                    item.setDateReported(parsed);
                }
            } catch (DateTimeParseException e) {
                errors.add("Date reported is not a valid date.");
            }
        }
        return item;
    }
}
