package lostfound.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.UserBean;
import lostfound.db.DatabaseException;
import lostfound.db.UserDB;
import lostfound.util.PasswordHelper;
import lostfound.util.SessionHelper;
import lostfound.util.Validator;

/** USER REGISTRATION. Receives the form from register.jsp (HTTP POST, Notes 6.1). */
public class RegisterServlet extends HttpServlet {

    private final UserDB userDB = new UserDB();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/register.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();

        String fullName = Validator.clean(request.getParameter("fullName"));
        String email = Validator.clean(request.getParameter("email")).toLowerCase();
        String contact = Validator.clean(request.getParameter("contactNumber"));
        String password = request.getParameter("password") == null ? "" : request.getParameter("password");
        String confirm = request.getParameter("confirmPassword") == null ? "" : request.getParameter("confirmPassword");

        // 1. Required-field and format validation
        List<String> errors = new ArrayList<String>();
        if (fullName.isEmpty()) {
            errors.add("Full name is required.");
        } else if (fullName.length() > 100) {
            errors.add("Full name must be 100 characters or fewer.");
        }
        if (email.isEmpty()) {
            errors.add("Email address is required.");
        } else if (!Validator.isValidEmail(email)) {
            errors.add("Please enter a valid email address.");
        }
        if (contact.isEmpty()) {
            errors.add("Contact number is required.");
        } else if (!Validator.isValidPhone(contact)) {
            errors.add("Please enter a valid contact number (digits, spaces and + ( ) - only).");
        }
        if (password.isEmpty()) {
            errors.add("Password is required.");
        } else if (!Validator.isValidPassword(password)) {
            errors.add(Validator.PASSWORD_RULE);
        } else if (!password.equals(confirm)) {
            errors.add("The two passwords do not match.");
        }

        // 2. Email uniqueness, then store in MySQL
        if (errors.isEmpty()) {
            try {
                if (userDB.emailExists(email, 0)) {
                    errors.add("An account with that email address already exists.");
                } else {
                    UserBean user = new UserBean();
                    user.setFullName(fullName);
                    user.setEmail(email);
                    user.setContactNumber(contact);
                    user.setPassword(PasswordHelper.hash(password));
                    userDB.register(user);

                    SessionHelper.message(session, "Registration successful! You can now log in.");
                    response.sendRedirect(request.getContextPath() + "/login.jsp");
                    return;
                }
            } catch (DatabaseException e) {
                if (e.isDuplicateEntry()) {
                    errors.add("An account with that email address already exists.");
                } else {
                    System.err.println("Registration failed: " + e.getMessage());
                    errors.add("A database error occurred. Please try again later.");
                }
            }
        }

        // 3. Something was wrong: go back to the form and keep what the user typed (never the password)
        UserBean typed = new UserBean();
        typed.setFullName(fullName);
        typed.setEmail(email);
        typed.setContactNumber(contact);
        session.setAttribute("formUser", typed);
        SessionHelper.errors(session, errors);
        response.sendRedirect(request.getContextPath() + "/register.jsp");
    }
}
