package lostfound.servlets;

import java.io.IOException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.UserBean;
import lostfound.db.DatabaseException;
import lostfound.db.UserDB;
import lostfound.util.PasswordHelper;
import lostfound.util.SessionHelper;
import lostfound.util.Validator;

/** USER LOGIN. Checks the email and password against the database and creates the session. */
public class LoginServlet extends HttpServlet {

    private final UserDB userDB = new UserDB();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        String email = Validator.clean(request.getParameter("email")).toLowerCase();
        String password = request.getParameter("password") == null ? "" : request.getParameter("password");

        String error = null;
        if (email.isEmpty() || password.isEmpty()) {
            error = "Please enter your email address and password.";
        } else {
            try {
                UserBean user = userDB.findByEmail(email);
                if (user != null && PasswordHelper.verify(password, user.getPassword())) {
                    user.setPassword("");   // the stored hash is never kept in the session

                    // Start a brand-new session for the logged-in user
                    HttpSession old = request.getSession(false);
                    if (old != null) {
                        old.invalidate();
                    }
                    HttpSession session = request.getSession(true);
                    session.setAttribute("user", user);
                    session.setMaxInactiveInterval(30 * 60);   // 30 minutes (Notes 7.1)
                    response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
                    return;
                }
                // The same message for "no such email" and "wrong password"
                error = "Invalid email address or password.";
            } catch (DatabaseException e) {
                System.err.println("Login failed: " + e.getMessage());
                error = "A database error occurred. Please try again later.";
            }
        }

        HttpSession session = request.getSession();
        UserBean typed = new UserBean();
        typed.setEmail(email);
        session.setAttribute("formUser", typed);
        SessionHelper.error(session, error);
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }
}
