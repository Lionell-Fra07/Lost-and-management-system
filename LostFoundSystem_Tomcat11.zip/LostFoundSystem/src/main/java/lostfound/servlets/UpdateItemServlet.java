package lostfound.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lostfound.beans.ItemBean;
import lostfound.beans.UserBean;
import lostfound.db.DatabaseException;
import lostfound.db.ItemDB;
import lostfound.util.LogWriter;
import lostfound.util.SessionHelper;

/** UPDATE ITEM. Saves changes to an existing item. */
public class UpdateItemServlet extends HttpServlet {

    private final ItemDB itemDB = new ItemDB();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/items.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        UserBean user = SessionHelper.getUser(session);
        if (user == null) {
            SessionHelper.error(session, "Please log in to continue.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int id = parseId(request.getParameter("id"));
        try {
            ItemBean existing = itemDB.findById(id);
            if (existing == null) {
                SessionHelper.error(session, "That item could not be found. It may have been deleted.");
                response.sendRedirect(request.getContextPath() + "/items.jsp");
                return;
            }

            List<String> errors = new ArrayList<String>();
            ItemBean item = ItemForm.read(request, errors, true);
            item.setItemId(id);
            item.setUserId(existing.getUserId());   // the reporter never changes

            if (errors.isEmpty()) {
                itemDB.update(item);
                LogWriter.log(user.getEmail(), LogWriter.UPDATED, item.getItemName());
                SessionHelper.message(session, "Item updated successfully.");
                response.sendRedirect(request.getContextPath() + "/item-view.jsp?id=" + id);
                return;
            }
            session.setAttribute("formItem", item);
            SessionHelper.errors(session, errors);
            response.sendRedirect(request.getContextPath() + "/item-form.jsp?id=" + id);
        } catch (DatabaseException e) {
            System.err.println("Update item failed: " + e.getMessage());
            SessionHelper.error(session, "A database error occurred. Please try again later.");
            response.sendRedirect(request.getContextPath() + "/items.jsp");
        }
    }

    private int parseId(String text) {
        try {
            return Integer.parseInt(text == null ? "" : text.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
