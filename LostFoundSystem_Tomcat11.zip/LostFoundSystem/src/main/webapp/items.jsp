<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%@ include file="includes/checkLogin.jspf" %>
<jsp:useBean id="itemDB" class="lostfound.db.ItemDB" />
<%
    String pageTitle = "Items";

    // Search box (Notes 7.1: request.getParameter). No search text = show everything.
    request.setCharacterEncoding("UTF-8");
    String q = Validator.clean(request.getParameter("q"));
    String by = Validator.clean(request.getParameter("by"));
    if (!"name".equals(by) && !"location".equals(by)) {
        by = "both";
    }
    List<ItemBean> items = q.isEmpty() ? itemDB.findAll() : itemDB.search(q, by);
%>
<%@ include file="includes/header.jspf" %>

<div class="page-head">
    <h1>Lost and found items</h1>
    <a class="btn" href="<%= ctx %>/item-form.jsp">Report an item</a>
</div>

<form id="search" action="<%= ctx %>/items.jsp" method="get" class="search-form card">
    <div>
        <label for="q">Search</label>
        <input type="text" id="q" name="q" value="<%= Validator.html(q) %>" placeholder="e.g. wallet or library">
    </div>
    <div>
        <label for="by">Search by</label>
        <select id="by" name="by">
            <option value="both" <%= "both".equals(by) ? "selected" : "" %>>Item name or location</option>
            <option value="name" <%= "name".equals(by) ? "selected" : "" %>>Item name</option>
            <option value="location" <%= "location".equals(by) ? "selected" : "" %>>Location</option>
        </select>
    </div>
    <div class="search-buttons">
        <button type="submit" class="btn">Search</button>
        <% if (!q.isEmpty()) { %><a class="btn btn-secondary" href="<%= ctx %>/items.jsp">Clear</a><% } %>
    </div>
</form>

<% if (!q.isEmpty()) { %>
    <p class="muted"><%= items.size() %> result(s) for "<%= Validator.html(q) %>".</p>
<% } %>

<% if (items.isEmpty()) { %>
    <p class="muted">No items found.</p>
<% } else { %>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Item</th><th>Type</th><th>Location</th><th>Date reported</th>
                    <th>Report</th><th>Status</th><th>Claim deadline</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <% for (ItemBean item : items) { %>
                <tr>
                    <td><a href="<%= ctx %>/item-view.jsp?id=<%= item.getItemId() %>"><%= Validator.html(item.getItemName()) %></a></td>
                    <td><%= Validator.html(item.getItemType()) %></td>
                    <td><%= Validator.html(item.getLocation()) %></td>
                    <td><%= item.getDateReportedText() %></td>
                    <td><span class="badge badge-<%= item.getReportType().toLowerCase() %>"><%= item.getReportType() %></span></td>
                    <td><span class="badge badge-<%= item.getStatus().toLowerCase() %>"><%= item.getStatus() %></span></td>
                    <td>
                        <%-- The deadline is only worked out and shown for Found items --%>
                        <% if (item.isFound()) { %>
                            <%= item.getClaimDeadlineText() %>
                            <% if (item.isDeadlinePassed()) { %><span class="badge badge-overdue">Overdue</span><% } %>
                        <% } else { %>
                            &mdash;
                        <% } %>
                    </td>
                    <td class="row-actions">
                        <a href="<%= ctx %>/item-form.jsp?id=<%= item.getItemId() %>">Edit</a>
                        <% if (!item.isClaimed()) { %>
                        <form action="<%= ctx %>/claim-item" method="post" class="inline">
                            <input type="hidden" name="id" value="<%= item.getItemId() %>">
                            <button type="submit" class="link-btn">Mark claimed</button>
                        </form>
                        <% } %>
                        <a class="danger" href="<%= ctx %>/item-delete.jsp?id=<%= item.getItemId() %>">Delete</a>
                    </td>
                </tr>
            <% } %>
            </tbody>
        </table>
    </div>
<% } %>

<%@ include file="includes/footer.jspf" %>
