<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, java.time.LocalDate, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%@ include file="includes/checkLogin.jspf" %>
<jsp:useBean id="itemDB" class="lostfound.db.ItemDB" />
<%
    // This one page is used for "Report an item" (no id) and "Update item" (?id=7).
    ItemBean item = (ItemBean) session.getAttribute("formItem");   // what the user typed before an error
    session.removeAttribute("formItem");

    int itemId = 0;
    try {
        itemId = Integer.parseInt(Validator.clean(request.getParameter("id")));
    } catch (NumberFormatException e) {
        itemId = 0;
    }
    boolean editing = itemId > 0;

    if (item == null && editing) {
        item = itemDB.findById(itemId);
        if (item == null) {
            SessionHelper.error(session, "That item could not be found. It may have been deleted.");
            response.sendRedirect(request.getContextPath() + "/items.jsp");
            return;
        }
    }
    if (item == null) {                       // a brand-new report
        item = new ItemBean();
        item.setDateReported(LocalDate.now());
    }

    String pageTitle = editing ? "Update item" : "Report an item";
%>
<%@ include file="includes/header.jspf" %>

<section class="card">
    <h1><%= pageTitle %></h1>
    <form action="<%= ctx %>/<%= editing ? "update-item" : "add-item" %>" method="post">
        <% if (editing) { %><input type="hidden" name="id" value="<%= itemId %>"><% } %>

        <div class="grid">
            <div>
                <label for="itemName">Item name</label>
                <input type="text" id="itemName" name="itemName" maxlength="100"
                       value="<%= Validator.html(item.getItemName()) %>" placeholder="e.g. Wallet, Keys, Laptop" required>
            </div>
            <div>
                <label for="itemType">Item type</label>
                <select id="itemType" name="itemType" required>
                    <option value="">Choose a type...</option>
                    <% for (String type : ItemBean.TYPES) { %>
                    <option value="<%= type %>" <%= type.equals(item.getItemType()) ? "selected" : "" %>><%= type %></option>
                    <% } %>
                </select>
            </div>
            <div>
                <label for="location">Location</label>
                <input type="text" id="location" name="location" maxlength="150"
                       value="<%= Validator.html(item.getLocation()) %>" placeholder="Where it was lost or found" required>
            </div>
            <div>
                <label for="dateReported">Date reported</label>
                <input type="date" id="dateReported" name="dateReported" max="<%= LocalDate.now() %>"
                       value="<%= item.getDateReportedIso() %>" required>
            </div>
            <div>
                <label for="reportType">Report type</label>
                <select id="reportType" name="reportType" required>
                    <option value="Lost" <%= item.isFound() ? "" : "selected" %>>Lost</option>
                    <option value="Found" <%= item.isFound() ? "selected" : "" %>>Found</option>
                </select>
                <small class="hint">Found items get a claim deadline of 14 days after the date reported.</small>
            </div>
            <div>
                <label for="status">Status</label>
                <% if (editing) { %>
                <select id="status" name="status">
                    <option value="Unclaimed" <%= item.isClaimed() ? "" : "selected" %>>Unclaimed</option>
                    <option value="Claimed" <%= item.isClaimed() ? "selected" : "" %>>Claimed</option>
                </select>
                <% } else { %>
                <input type="text" id="status" value="Unclaimed" disabled>
                <small class="hint">New items always start as Unclaimed.</small>
                <% } %>
            </div>
        </div>

        <label for="description">Description</label>
        <textarea id="description" name="description" rows="4" maxlength="500"
                  placeholder="Colour, brand, size or other identifying features" required><%= Validator.html(item.getDescription()) %></textarea>

        <div class="actions">
            <button type="submit" class="btn"><%= editing ? "Save changes" : "Submit report" %></button>
            <a class="btn btn-secondary" href="<%= ctx %>/items.jsp">Cancel</a>
        </div>
    </form>
</section>

<%@ include file="includes/footer.jspf" %>
