<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%@ include file="includes/checkLogin.jspf" %>
<jsp:useBean id="itemDB" class="lostfound.db.ItemDB" />
<jsp:useBean id="userDB" class="lostfound.db.UserDB" />
<%
    int itemId = 0;
    try {
        itemId = Integer.parseInt(Validator.clean(request.getParameter("id")));
    } catch (NumberFormatException e) {
        itemId = 0;
    }
    ItemBean item = itemDB.findById(itemId);
    if (item == null) {
        SessionHelper.error(session, "That item could not be found. It may have been deleted.");
        response.sendRedirect(request.getContextPath() + "/items.jsp");
        return;
    }
    UserBean reporter = userDB.findById(item.getUserId());
    String pageTitle = "Item details";
%>
<%@ include file="includes/header.jspf" %>

<section class="card">
    <div class="page-head">
        <h1><%= Validator.html(item.getItemName()) %></h1>
        <span>
            <span class="badge badge-<%= item.getReportType().toLowerCase() %>"><%= item.getReportType() %></span>
            <span class="badge badge-<%= item.getStatus().toLowerCase() %>"><%= item.getStatus() %></span>
        </span>
    </div>

    <dl class="details">
        <dt>Item type</dt><dd><%= Validator.html(item.getItemType()) %></dd>
        <dt>Description</dt><dd><%= Validator.html(item.getDescription()) %></dd>
        <dt>Location</dt><dd><%= Validator.html(item.getLocation()) %></dd>
        <dt>Date reported</dt><dd><%= item.getDateReportedText() %></dd>
        <dt>Reported by</dt><dd><%= reporter == null ? "Unknown" : Validator.html(reporter.getFullName()) %></dd>
        <dt>Claim deadline</dt>
        <dd>
            <% if (item.isFound()) { %>
                <strong><%= item.getClaimDeadlineText() %></strong>
                <% if (item.isDeadlinePassed()) { %><span class="badge badge-overdue">Overdue</span><% } %>
            <% } else { %>
                <span class="muted">Not applicable (only found items have a claim deadline)</span>
            <% } %>
        </dd>
    </dl>

    <div class="actions">
        <a class="btn" href="<%= ctx %>/item-form.jsp?id=<%= item.getItemId() %>">Edit</a>
        <% if (!item.isClaimed()) { %>
        <form action="<%= ctx %>/claim-item" method="post" class="inline">
            <input type="hidden" name="id" value="<%= item.getItemId() %>">
            <input type="hidden" name="from" value="view">
            <button type="submit" class="btn btn-secondary">Mark as claimed</button>
        </form>
        <% } %>
        <a class="btn btn-danger" href="<%= ctx %>/item-delete.jsp?id=<%= item.getItemId() %>">Delete</a>
        <a class="btn btn-secondary" href="<%= ctx %>/items.jsp">Back to list</a>
    </div>
</section>

<%@ include file="includes/footer.jspf" %>
