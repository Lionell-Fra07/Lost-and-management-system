<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%@ include file="includes/checkLogin.jspf" %>
<jsp:useBean id="itemDB" class="lostfound.db.ItemDB" />
<%
    int itemId = 0;
    try {
        itemId = Integer.parseInt(Validator.clean(request.getParameter("id")));
    } catch (NumberFormatException e) {
        itemId = 0;
    }
    ItemBean item = itemDB.findById(itemId);
    if (item == null) {
        SessionHelper.error(session, "That item could not be found. It may have been deleted already.");
        response.sendRedirect(request.getContextPath() + "/items.jsp");
        return;
    }
    String pageTitle = "Delete item";
%>
<%@ include file="includes/header.jspf" %>

<section class="card narrow">
    <h1>Delete this item?</h1>
    <p>You are about to delete <strong><%= Validator.html(item.getItemName()) %></strong>
       (<%= item.getReportType() %>, reported <%= item.getDateReportedText() %>).
       This cannot be undone.</p>
    <form action="<%= ctx %>/delete-item" method="post" class="actions">
        <input type="hidden" name="id" value="<%= item.getItemId() %>">
        <button type="submit" class="btn btn-danger">Yes, delete it</button>
        <a class="btn btn-secondary" href="<%= ctx %>/items.jsp">Cancel</a>
    </form>
</section>

<%@ include file="includes/footer.jspf" %>
