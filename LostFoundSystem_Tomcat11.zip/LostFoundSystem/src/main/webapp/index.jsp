<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%-- jsp:forward action (Notes 7.1): the dashboard sends visitors who are not logged in to the login page --%>
<jsp:forward page="dashboard.jsp" />
