<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%
    if (SessionHelper.getUser(session) != null) {
        response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
        return;
    }
    UserBean typed = (UserBean) session.getAttribute("formUser");
    session.removeAttribute("formUser");
    if (typed == null) {
        typed = new UserBean();
    }
    String pageTitle = "Register";
%>
<%@ include file="includes/header.jspf" %>

<section class="card narrow">
    <h1>Create an account</h1>
    <form action="<%= ctx %>/register" method="post">
        <label for="fullName">Full name</label>
        <input type="text" id="fullName" name="fullName" maxlength="100" value="<%= Validator.html(typed.getFullName()) %>" required>

        <label for="email">Email address</label>
        <input type="email" id="email" name="email" maxlength="150" value="<%= Validator.html(typed.getEmail()) %>" required>

        <label for="contactNumber">Contact number</label>
        <input type="tel" id="contactNumber" name="contactNumber" maxlength="20" value="<%= Validator.html(typed.getContactNumber()) %>" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        <small class="hint">At least 8 characters, with a letter and a number.</small>

        <label for="confirmPassword">Confirm password</label>
        <input type="password" id="confirmPassword" name="confirmPassword" required>

        <button type="submit" class="btn">Register</button>
    </form>
    <p class="muted">Already registered? <a href="<%= ctx %>/login.jsp">Log in</a>.</p>
</section>

<%@ include file="includes/footer.jspf" %>
