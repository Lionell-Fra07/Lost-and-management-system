<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%@ include file="includes/checkLogin.jspf" %>
<jsp:useBean id="userDB" class="lostfound.db.UserDB" />
<%
    // Show what the user typed if the last attempt had errors, otherwise the saved details
    UserBean profile = (UserBean) session.getAttribute("formUser");
    session.removeAttribute("formUser");
    if (profile == null) {
        profile = userDB.findById(SessionHelper.getUser(session).getUserId());
    }
    String pageTitle = "My profile";
%>
<%@ include file="includes/header.jspf" %>

<section class="card narrow">
    <h1>My profile</h1>
    <form action="<%= ctx %>/profile-update" method="post">
        <label for="fullName">Full name</label>
        <input type="text" id="fullName" name="fullName" maxlength="100" value="<%= Validator.html(profile.getFullName()) %>" required>

        <label for="email">Email address</label>
        <input type="email" id="email" name="email" maxlength="150" value="<%= Validator.html(profile.getEmail()) %>" required>

        <label for="contactNumber">Contact number</label>
        <input type="tel" id="contactNumber" name="contactNumber" maxlength="20" value="<%= Validator.html(profile.getContactNumber()) %>" required>

        <h2>Change password <span class="muted small">(optional)</span></h2>
        <label for="currentPassword">Current password</label>
        <input type="password" id="currentPassword" name="currentPassword">

        <label for="newPassword">New password</label>
        <input type="password" id="newPassword" name="newPassword">
        <small class="hint">Leave blank to keep your current password.</small>

        <label for="confirmPassword">Confirm new password</label>
        <input type="password" id="confirmPassword" name="confirmPassword">

        <button type="submit" class="btn">Save profile</button>
    </form>
</section>

<%@ include file="includes/footer.jspf" %>
