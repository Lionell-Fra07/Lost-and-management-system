<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%@ include file="includes/checkLogin.jspf" %>
<%-- jsp:useBean (Notes 7.1 / 8.1): creates the object that talks to the database --%>
<jsp:useBean id="itemDB" class="lostfound.db.ItemDB" />
<%
    String pageTitle = "Dashboard";
    UserBean loggedIn = SessionHelper.getUser(session);
    int total = itemDB.countAll();
    int unclaimed = itemDB.countByStatus(ItemBean.UNCLAIMED);
    int claimed = itemDB.countByStatus(ItemBean.CLAIMED);
    List<ItemBean> recent = itemDB.findRecent(5);
%>
<%@ include file="includes/header.jspf" %>

<h1>Welcome, <%= Validator.html(loggedIn.getFullName()) %>!</h1>
<p class="muted">Here is an overview of the lost and found items on the system.</p>

<section class="stats">
    <div class="card stat">
        <span class="stat-num"><%= total %></span>
        <span class="stat-label">Total reported items</span>
    </div>
    <div class="card stat">
        <span class="stat-num"><%= unclaimed %></span>
        <span class="stat-label">Unclaimed items</span>
    </div>
    <div class="card stat">
        <span class="stat-num"><%= claimed %></span>
        <span class="stat-label">Claimed items</span>
    </div>
</section>

<section class="actions">
    <a class="btn" href="<%= ctx %>/item-form.jsp">Report an item</a>
    <a class="btn btn-secondary" href="<%= ctx %>/items.jsp">View all items</a>
    <a class="btn btn-secondary" href="<%= ctx %>/items.jsp#search">Search items</a>
    <a class="btn btn-secondary" href="<%= ctx %>/profile.jsp">My profile</a>
</section>

<h2>Recently reported</h2>
<% if (recent.isEmpty()) { %>
    <p class="muted">No items have been reported yet.</p>
<% } else { %>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Item</th><th>Location</th><th>Date reported</th><th>Report</th><th>Status</th></tr>
            </thead>
            <tbody>
            <% for (ItemBean item : recent) { %>
                <tr>
                    <td><a href="<%= ctx %>/item-view.jsp?id=<%= item.getItemId() %>"><%= Validator.html(item.getItemName()) %></a></td>
                    <td><%= Validator.html(item.getLocation()) %></td>
                    <td><%= item.getDateReportedText() %></td>
                    <td><span class="badge badge-<%= item.getReportType().toLowerCase() %>"><%= item.getReportType() %></span></td>
                    <td><span class="badge badge-<%= item.getStatus().toLowerCase() %>"><%= item.getStatus() %></span></td>
                </tr>
            <% } %>
            </tbody>
        </table>
    </div>
<% } %>

<%@ include file="includes/footer.jspf" %>
