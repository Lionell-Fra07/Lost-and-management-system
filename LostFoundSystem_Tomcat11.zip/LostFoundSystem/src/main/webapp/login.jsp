<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         errorPage="error.jsp" %>
<%
    // Already logged in? Go straight to the dashboard.
    if (SessionHelper.getUser(session) != null) {
        response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
        return;
    }
    // ?msg=loggedout comes from the LogoutServlet (fixed text only, nothing typed by a user is printed)
    if ("loggedout".equals(request.getParameter("msg"))) {
        SessionHelper.message(session, "You have been logged out.");
    }
    UserBean typed = (UserBean) session.getAttribute("formUser");
    session.removeAttribute("formUser");
    String typedEmail = typed == null ? "" : typed.getEmail();
    String pageTitle = "Log in";
%>
<%@ include file="includes/header.jspf" %>

<section class="card narrow">
    <h1>Log in</h1>
    <form action="<%= ctx %>/login" method="post">
        <label for="email">Email address</label>
        <input type="email" id="email" name="email" value="<%= Validator.html(typedEmail) %>" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>

        <button type="submit" class="btn">Log in</button>
    </form>
    <p class="muted">No account yet? <a href="<%= ctx %>/register.jsp">Register here</a>.</p>
</section>

<%@ include file="includes/footer.jspf" %>
