<%@ page contentType="text/html;charset=UTF-8" language="java"
         import="java.util.*, lostfound.beans.*, lostfound.util.*"
         isErrorPage="true" %>
<%
    // Error page (Notes 7.1: errorPage / isErrorPage / exception object).
    // The technical details go to the server console, not to the visitor.
    if (exception != null) {
        System.err.println("Page error: " + exception);
    }
    String pageTitle = "Something went wrong";
%>
<%@ include file="includes/header.jspf" %>

<section class="card narrow">
    <h1>Something went wrong</h1>
    <p>An unexpected error occurred. Please check that MySQL is running, then try again.</p>
    <a class="btn" href="<%= ctx %>/dashboard.jsp">Back to the dashboard</a>
</section>

<%@ include file="includes/footer.jspf" %>
