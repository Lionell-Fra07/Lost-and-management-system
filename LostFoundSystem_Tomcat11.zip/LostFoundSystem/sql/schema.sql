-- Lost and Found Management System - MySQL database
-- Run in MySQL Workbench: File > Open SQL Script, then click the lightning bolt.
-- (Notes 4.1: a schema is the same thing as a database.)

CREATE DATABASE IF NOT EXISTS lostfound_db;
USE lostfound_db;

-- 1. USERS TABLE: one row for every registered user
CREATE TABLE IF NOT EXISTS Users (
    user_id        INT          NOT NULL AUTO_INCREMENT,   -- primary key
    full_name      VARCHAR(100) NOT NULL,
    email          VARCHAR(150) NOT NULL,
    password       VARCHAR(255) NOT NULL,                  -- stored as salt:hash, never plain text
    contact_number VARCHAR(20)  NOT NULL,
    PRIMARY KEY (user_id),
    UNIQUE (email)                                         -- every email address can be used once only
);

-- 2. LOSTFOUNDITEMS TABLE: one row for every lost or found item
-- The claim deadline is NOT stored. The application works it out (Date Reported + 14 days, Found items only).
CREATE TABLE IF NOT EXISTS LostFoundItems (
    item_id       INT          NOT NULL AUTO_INCREMENT,    -- primary key
    user_id       INT          NOT NULL,                   -- the user who reported the item
    item_name     VARCHAR(100) NOT NULL,
    item_type     VARCHAR(50)  NOT NULL,
    description   VARCHAR(500) NOT NULL,
    location      VARCHAR(150) NOT NULL,
    date_reported DATE         NOT NULL,
    report_type   ENUM('Lost','Found')        NOT NULL,
    status        ENUM('Unclaimed','Claimed') NOT NULL DEFAULT 'Unclaimed',
    PRIMARY KEY (item_id),
    FOREIGN KEY (user_id) REFERENCES Users (user_id)       -- links each item to its reporter
        ON DELETE CASCADE
);
